# 怪猫SDK 分享功能集成 2021/10/21

## 拷贝相关资源文件 libs，jniLibs，res



# 首先，需要在怪猫后台管理对应的游戏中，填写各分享渠道平台所申请的分享参数（如微信的ClientId、抖音的Client Key等）



 其中对应参数由怪猫方运营提供 其他对应资源，若有同名文件在，请仅保留对应文件内的资源即可。如： res/values/style.xml


## 复制AndroidManifest.xml内相关资源，合并到项目AndroidManifest.xml 内

初始化 在调用分享之前请先设置分享回调,在主Activity的onCreate内

```java
SharePlatform.setShareCallback(new ShareCallbackManager.ShareCallback() { 
    @Override
     public void shareSucc() { 
        Toast.makeText(MainActivity.this,"分享成功",Toast.LENGTH_LONG).show(); 
    }
    @Override 
    public void shareFailed() { 
        Toast.makeText(MainActivity.this,"分享失败",Toast.LENGTH_LONG).show(); 
    } });

```

在主Activity内重写onActivityResult
```java
SharePlatform.onActivityResult(requestCode,resultCode,data);
```

## 调用分享
目前支持的分享渠道:微博、微信、微信朋友圈、QQ、QQ空间、抖音

### 使用自传参数分享
SharePlatform.share();
```java
ShareBean shareBean = new ShareBean(); 
shareBean.setUrl("https://www.baidu.com"); 
shareBean.setImgpath("https://img.iplaysoft.com/wp- content/uploads/2019/free-images/free_stock_photo.jpg"); 
shareBean.setVideoPath("http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4");
shareBean.setMsg("测试内容"); 
shareBean.setTitle("测试标题"); 

SharePlatform.share(MainActivity.this,shareBean);

```

ShareBean属性
title:分享出去后显示的标题 
msg:分享出去后显示的正文/摘要 
imgpath: 需要分享出去的图片地址 (URL地址) 
videoPath: 需要分享出去的视频地址 (URL地址,视频格式建议为MP4) 
url：需要分享出去的链接地址 

### 各分享渠分享内容支持

微博：支持纯文字、文字图片（带链接）、纯图片、视频
微信/朋友圈：支持纯文字、文字图片（带链接）、纯图片、视频
QQ:支持文字图片（带链接）、纯图片
QQ空间:支持文字图片（带链接）、纯图片、纯视频
抖音：仅支持单图片/视频

必要参数
微信，微博：图片/视频/标题/正文，必须有其一
QQ好友：标题/正文，必须有其一，链接、图片有其一（建议有，不然会分享空链接，使得分享意义不大）
QQ空间：标题/正文，必须有其一，链接、图片有其一（建议有，不然会分享空链接，使得分享意义不大）
抖音：图片/视频，必须有其一

若参数中没有出现渠道中必要的参数，则不会在分享选择界面中出现该渠道

### 参数类型优先级
若shareBean参数同时出现视频、图片、文字参数，则按视频>图片>链接>纯文字的规则来决定适配对应渠道的分享内容。

示例:
```java
				shareBean.setImgpath("http://demo.gm88.com/uploads/tmp/1632825253.jpeg");
				shareBean.setUrl(edtUrl.getText().toString());
                shareBean.setVideoPath("http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4");
                shareBean.setMsg("testMsg");
                shareBean.setTitle("testTitle");
```

分享参数同时有视频、图片、文字内容和标题，因视频优先级高于图片，所以会将该分享视为视频分享

### 使用后台配置分享
```java
SharePlatform.shareWithId(DemoShareActivity.this,"459963");
```

调用此方法，可按怪猫后台配置的内容（标题、文字内容、图片）进行分享，无需额外传参数





